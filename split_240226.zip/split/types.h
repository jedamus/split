/* -*- C -*- */
/* types.h */
/* erzeugt Montag, 26. Februar 2024 11:51 (C) 2024 von Leander Jedamus */
/* modifiziert Montag, 26. Februar 2024 12:28 von Leander Jedamus */

#ifndef TYPES_H
#define TYPES_H 1

typedef enum { FALSE, TRUE} boolean;

#endif /* TYPES_H */

/* vim:set cindent ai sw=2 */

