#!/usr/bin/env sh

# erzeugt Freitag, 16. Februar 2024 19:38 (C) 2024 von Leander Jedamus
# modifiziert Freitag, 23. Februar 2024 13:33 von Leander Jedamus
# modifiziert Donnerstag, 22. Februar 2024 17:42 von Leander Jedamus
# modifiziert Sonntag, 18. Februar 2024 09:22 von Leander Jedamus
# modifiziert Freitag, 16. Februar 2024 20:24 von Leander Jedamus

# set -x

basename=project
inputfilename=$basename.txt
filename=$basename.h
author="Leander Jedamus"
email="ljedamus@web.de"

# FILENAME=$(echo $filename | sed -e 's/\./_/' | tr a-z A-Z)
FILENAME=$(echo $filename | sed -e 's/\./_/g' | tr [:lower:] [:upper:])
YEAR=$(date +"%Y")
DATETIME=$(date +"%A, %d. %B %Y %H:%M")

if [ ! -f $inputfilename ]; then
  echo "$inputfilename not found."
  exit 1
fi

cat <<EOF > $filename
/* -*- C -*- */
/* $filename */
/* erzeugt $DATETIME (C) $YEAR von $author */
/* modifiziert $DATETIME von $author */

#ifndef $FILENAME
#define $FILENAME 1

#define PROJECT "$(cat $inputfilename)"
#define AUTHOR "$author"
#define EMAIL "$email"
#define YEARS "$YEAR"

#endif /* $FILENAME */

/* vim:set cindent ai sw=2 */

EOF

# vim:ai sw=2

