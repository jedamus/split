/* -*- C -*- */
/* project.h */
/* erzeugt Freitag, 23. Februar 2024 13:34 (C) 2024 von Leander Jedamus */
/* modifiziert Freitag, 23. Februar 2024 13:34 von Leander Jedamus */

#ifndef PROJECT_H
#define PROJECT_H 1

#define PROJECT "split"
#define AUTHOR "Leander Jedamus"
#define EMAIL "ljedamus@web.de"
#define YEARS "2024"

#endif /* PROJECT_H */

/* vim:set cindent ai sw=2 */

