/* -*- C -*- */
/* version.h */
/* erzeugt Montag, 12. August 2024 10:22 (C) 2024 von Leander Jedamus */
/* modifiziert Montag, 12. August 2024 10:22 von Leander Jedamus */

#ifndef VERSION_H
#define VERSION_H 1

#define VERSION "1.1"

#endif /* VERSION_H */

/* vim:set cindent ai sw=2 */

