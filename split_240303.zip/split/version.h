/* -*- C -*- */
/* version.h */
/* erzeugt Freitag, 23. Februar 2024 13:34 (C) 2024 von Leander Jedamus */
/* modifiziert Freitag, 23. Februar 2024 13:34 von Leander Jedamus */

#ifndef VERSION_H
#define VERSION_H 1

#define VERSION "1.1"

#endif /* VERSION_H */

/* vim:set cindent ai sw=2 */

