/* -*- C -*- */
/* project.h */
/* erzeugt Freitag, 16. Februar 2024 20:24 (C) 2024 von Leander Jedamus */
/* modifiziert Freitag, 16. Februar 2024 20:24 von Leander Jedamus */

#ifndef PROJECT_H
#define PROJECT_H 1

#define PROJECT "split"

#endif /* PROJECT_H */

/* vim:set cindent ai sw=2 */

