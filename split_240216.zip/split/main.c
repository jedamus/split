/* -*- C -*- */
/* main.c */
/* erzeugt Freitag, 26. Januar 2024 14:48 (C) 2024 von Leander Jedamus */
/* modifiziert Freitag, 16. Februar 2024 15:10 von Leander Jedamus */
/* modifiziert Montag, 29. Januar 2024 07:05 von Leander Jedamus */
/* modifiziert Sonntag, 28. Januar 2024 06:12 von Leander Jedamus */
/* modifiziert Samstag, 27. Januar 2024 18:12 von Leander Jedamus */
/* modifiziert Freitag, 26. Januar 2024 19:47 von Leander Jedamus */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#if defined __linux__
  #include <linux/limits.h>
#elif defined __APPLE__
  #include <sys/syslimits.h>
#endif

#include "project.h"
#include "getlocaledir.h"
#include "gettext.h"

int main(int argc, char * argv[]) {

  size_t       size;
  size_t       wanted_size;
  size_t       len;
  char         filename[PATH_MAX*2+2+sizeof(size_t)];
  char         path[PATH_MAX];
  char         errmsg[PATH_MAX];
  size_t       nr      = 1;
  const size_t bufsize = 1024;
  char *       ptr;
  char         c;

  FILE *       rf;
  FILE *       wf;
  char *       localedir = getlocaledir(argv[0]);
  int          i;

#ifdef DEBUG
  printf("%s\n",localedir);
#endif

  setlocale(LC_ALL, "");
  bindtextdomain(PROJECT, localedir);
  textdomain(PROJECT);

  if (argc < 3) {
    printf(_("usage: %s <filename> <1M> [<output path>]\n"),argv[0]);
  } else {
    ptr = strrchr(argv[1], '/');
    if(ptr == NULL) {
      ptr = argv[1];
      strcpy(path, ".");
    } else {
      ++ptr;
      c = *ptr;
      *ptr = '\0';
      strcpy(path, argv[1]);
      *ptr = c;
    }
    if (argc == 4) {
      strcpy(path, argv[3]);
    };
#ifdef DEBUG
    printf(_("filename ='%s', path='%s'\n"), ptr, path);
#endif

    len = strlen(argv[2]);
    wanted_size = 0;
    for(i = 0; i < len; i++) {
      char d = argv[2][i];
#ifdef DEBUG
      printf("d=%c, ", d);
#endif
      if((d >= '0') && (d <= '9')) {
#ifdef DEBUG
	printf("=%d", d - '0');
#endif
	wanted_size = wanted_size * 10 + d - '0';
      } else {
	if(wanted_size == 0) wanted_size = 1;
	d = tolower(d);
	if(d == 'k') { wanted_size *= 1024; break; }
	if(d == 'm') { wanted_size *= 1024*1024; break; }
	if(d == 'g') { wanted_size *= 1024*1024*1024; break; }
	break;
      };/* else */
    };/* for i */
#ifdef DEBUG
    printf("wanted_size=%ld\n", wanted_size);
#endif
    if(wanted_size < bufsize) {
      printf(_("warning: size %ld too small,  now is %ld.\n"), wanted_size, bufsize);
      wanted_size = bufsize;
    }

    nr   = 1;
    size = 0;
    rf   = fopen(argv[1], "rb");
    if(rf == NULL) {
      sprintf(errmsg, _("error: fopen '%s'"), argv[1]);
#ifdef DEBUG
      printf("'%s'\n", _(strerror(errno)));
#endif
      /*
      if(strcmp(strerror(errno),"No such file or directory") == 0) {
      */
      if(errno == 2) {
	fprintf(stderr, "%s: %s\n", errmsg, "Datei oder Verzeichnis nicht gefunden");
      }
      return EXIT_FAILURE;
    }
    sprintf(filename,"%s/%s.%ld", path, ptr, nr);
#ifdef DEBUG
    printf("%s\n", filename);
#endif
    wf = fopen(filename, "wb");
    if(wf == NULL) {
      sprintf(errmsg, _("error: fopen '%s'"), filename);
#ifdef DEBUG
      printf("'%s'\n", _(strerror(errno)));
#endif
      /*
      if(strcmp(strerror(errno),"Is a directory") == 0) {
      */
      if(errno == 21) {
	fprintf(stderr, "%s: %s\n", errmsg, "Ist ein Verzeichnis");
      }
      return EXIT_FAILURE;
    }
    for(;;) {
      unsigned char buffer[bufsize];
      size_t        n = fread(buffer, 1, bufsize, rf);

      if(n < bufsize) {
	if(ferror(rf)) {
          sprintf(errmsg, _("error: fread '%s'"), argv[1]);
	  /* fprintf(stderr, _("error: fread\n")); */
          if(errno == 21) {
	    fprintf(stderr, "%s: %s\n", errmsg, "Ist ein Verzeichnis");
          }
	  /* perror("error: fread"); */
          return EXIT_FAILURE;
	}
      }

      if(n > 0) {
	if(fwrite(buffer, 1, n, wf) != n)
	  if(ferror(wf)) {
            sprintf(errmsg, _("error: fwrite '%s'"), filename);
	    /* fprintf(stderr, _("error: fwrite\n")); */
            if(errno == 21) {
	      fprintf(stderr, "%s: %s\n", errmsg, "Ist ein Verzeichnis");
            }
	    /* perror("error: fwrite"); */
            return EXIT_FAILURE;
	  }

	size += n;
	if(size >= wanted_size) {
	  fclose(wf);
	  nr++;
	  size = 0;
	  sprintf(filename,"%s/%s.%ld", path, ptr, nr);
#ifdef DEBUG
	  printf("%s\n", filename);
#endif
	  wf = fopen(filename, "wb");
          if(wf == NULL) {
	    sprintf(errmsg, _("error: fopen '%s'"), filename);
	    perror(errmsg);
	    return EXIT_FAILURE;
	  }
	};/* if size >= wanted_size */
      };/* if n > 0 */
      if(n < bufsize) break;
    }

    fclose(wf);
    fclose(rf);
  }

  return EXIT_SUCCESS;
}

/* vim:set cindent ai sw=2: */

