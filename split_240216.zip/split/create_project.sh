#!/usr/bin/env sh

# erzeugt Freitag, 16. Februar 2024 19:38 (C) 2024 von Leander Jedamus
# modifiziert Freitag, 16. Februar 2024 20:24 von Leander Jedamus

# set -x

filename=project.h
inputfilename=project.txt
user="Leander Jedamus"

# FILENAME=$(echo $filename | sed -e 's/\./_/' | tr a-z A-Z)
FILENAME=$(echo $filename | sed -e 's/\./_/' | tr [:lower:] [:upper:])
YEAR=$(date +"%Y")
DATETIME=$(date +"%A, %d. %B %Y %H:%M")

if [ ! -f $inputfilename ]; then
  echo "$inputfilename not found."
  exit 1
fi

cat <<EOF > $filename
/* -*- C -*- */
/* $filename */
/* erzeugt $DATETIME (C) $YEAR von $user */
/* modifiziert $DATETIME von $user */

#ifndef $FILENAME
#define $FILENAME 1

#define PROJECT "$(cat $inputfilename)"

#endif /* $FILENAME */

/* vim:set cindent ai sw=2 */

EOF

# vim:ai sw=2

